﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.

$(document).ready(function () {
    $('#UserTable').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'csvHtml5'
        ]
    });
});

$(document).ready(function () {
    $('#ScheduleTable').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'csvHtml5'
        ]
    });
});

$(document).ready(function () {
    $('#CandidateTable').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'csvHtml5'
        ]
    });
});

$(document).ready(function () {
    $('#DisciplinesTable').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'csvHtml5'
        ]
    });
});

$(document).ready(function () {
    $('#EmployeeTable').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'csvHtml5'
        ]
    });
});

$(document).ready(function () {
    $('#EstimateTable').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'csvHtml5'
        ]
    });
});

$(document).ready(function () {
    $('#ExpensesTable').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'csvHtml5'
        ]
    });
});

$(document).ready(function () {
    $('#InventoriesTable').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'csvHtml5'
        ]
    });
});

$(document).ready(function () {
    $('#InvoiceTable').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'csvHtml5'
        ]
    });
});

$(document).ready(function () {
    $('#LeavesTable').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'csvHtml5'
        ]
    });
});

$(document).ready(function () {
    $('#RunPayrollTable').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'csvHtml5'
        ]
    });
});

$(document).ready(function () {
    $('#ViewPayrollTable').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'csvHtml5'
        ]
    });
});

$(document).ready(function () {
    $('#GlPayrollTable').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'csvHtml5'
        ]
    });
});

$(document).ready(function () {
    $('#PerformanceTable').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'csvHtml5'
        ]
    });
});

$(document).ready(function () {
    $('#TimesTable').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'csvHtml5'
        ]
    });
});

$(document).ready(function () {
    $('#CustomerTable').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'csvHtml5'
        ]
    });
});

$(document).ready(function () {
    $('#DocumentMng').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'csvHtml5'
        ]
    });
});

$(document).ready(function () {
    $('#JournalEntryTable').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'csvHtml5'
        ]
    });
});

$(document).ready(function () {
    $('#BalanceSheetTable').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'csvHtml5'
        ]
    });
});

$(document).ready(function () {
    $('#IncomeStatementTable').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'csvHtml5'
        ]
    });
});

$(document).ready(function () {
    $('#EmailMarketingTable').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'csvHtml5'
        ]
    });
});

$(document).ready(function () {
    $('#BackgroundJobsTable').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'csvHtml5'
        ]
    });
});

$(document).ready(function () {
    $('#ComplaintTable').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'csvHtml5'
        ]
    });
});

$(document).ready(function () {
    $('#CustomReportTable').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'csvHtml5'
        ]
    });
});

