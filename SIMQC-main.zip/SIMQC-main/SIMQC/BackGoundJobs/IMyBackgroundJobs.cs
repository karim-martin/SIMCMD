﻿using System.Threading.Tasks;

namespace SIMQC.BackGroundJobs
{
    public interface IMyBackgroundJobs
    {
        public void DownloadFiles();

        public Task ConvertFilesAsync();

        public void ImportFiles();
    }
}